enum java {

    enum lang {
        enum String {}
    }
}