import 'package:flutter/material.dart';
class list{
    final String name ,ImageUrl,desc;

    list(this.name, this.ImageUrl, this.desc);



}