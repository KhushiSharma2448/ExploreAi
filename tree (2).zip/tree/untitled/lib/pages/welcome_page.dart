import 'dart:ui';

import 'package:flutter/material.dart';

import 'package:untitled/pages/second_page.dart';
import 'package:untitled/widgets/app_large_text.dart';
import 'package:untitled/widgets/responsive_button.dart';

import '../widgets/app_text.dart';





class WelcomePage extends StatefulWidget {
  const WelcomePage({Key? key}) : super(key: key);

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {


  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      height: double.maxFinite,

      decoration: const BoxDecoration(
          image: DecorationImage(
              image: NetworkImage(
                  'https://media.istockphoto.com/photos/trunk-isolated-picture-id1126153547?b=1&k=20&m=1126153547&s=170667a&w=0&h=0NgJQN7rOjaiJ5s-kP6n66unHWK0MwKFfYavaDjD9J8='),
              fit: BoxFit.cover
          )
      ),

      child:

    Container(
      margin:const EdgeInsets.only(top:150, left:20, right:20),

      child:Row(
        children: [

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
          children:[
            AppLargeText(text:"Tree"),
            AppText(text:"Tracker",size:30,),
            SizedBox(height:20,),
            Container(
              width:250,
              child:AppText(
                text:"Trees are poems that the earth writes upon the sky.",
              color:Colors.black,
                size:20,
              ),
            ),
            SizedBox(height:40,),
            ResponsiveButton(),



],




          )

],

    )
        ),
    );




  }


}













