class GradleException {
    GradleException(java.lang.String s) {
    }
}
