import 'package:flutter/material.dart';
class TreesDetail extends StatelessWidget {
  final list
  const TreesDetail({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title:
      Text(''),),
      body:Column(
        children: [Image.network('src'),
        Text('desc')],
      ),
    );
  }
}
