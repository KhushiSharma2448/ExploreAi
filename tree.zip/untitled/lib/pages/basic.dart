import 'package:flutter/material.dart';

import '../TreesDetail.dart';
import '../list.dart';
class Basic extends StatelessWidget {
  const Basic({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Basic(),

    );
  }
}

class Page extends StatefulWidget {
  const Page({Key? key}) : super(key: key);

  @override
  State<Page> createState() => _PageState();
}

class _PageState extends State<Page> {
  static List<String> treename=['Cedar','Cypress'];
  static List url=[];
  final List<list> treedata=List.generate(
    treename.length,
      (index)
      =>list('${treename[index]}','${url[index]}','${treename[index]}'));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pass Data'),),
      body:ListView.builder(
        itemCount:treedata.length,
        itemBuilder:(context,index){
          return Card(
            child:ListTile(
              title:Text(treedata[index].name),
              leading:SizedBox(
                width:50,
                height:50,
                child:Image.network(treedata[index].ImageUrl),
              ),
                onTap:(){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>TreesDetail()));
          },
            ),
          );
        }
      )
    );
  }
}
