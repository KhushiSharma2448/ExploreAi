import 'dart:ui';

import 'package:flutter/material.dart';

import 'package:untitled/pages/second_page.dart';
import 'package:untitled/widgets/responsive_button.dart';





class WelcomePage extends StatefulWidget {
  const WelcomePage({Key? key}) : super(key: key);

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {


  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      height: double.maxFinite,

      decoration: const BoxDecoration(
          image: DecorationImage(
              image: NetworkImage(
                  'https://images.unsplash.com/photo-1444492696363-332accfd40c0?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8YXV0dW1uJTIwdHJlZXxlbnwwfHwwfHw%3D&w=1000&q=80'),
              fit: BoxFit.cover
          )
      ),

      child:

    Container(
      alignment: Alignment.centerRight,
      child:Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(

           mainAxisAlignment: MainAxisAlignment.center,


          children:
          [RichText(
            text: TextSpan(

              style: DefaultTextStyle
                  .of(context)
                  .style,


              children: <TextSpan>[
                TextSpan(

                  text: " Tree",

                  style: TextStyle(fontStyle:FontStyle.italic,fontSize:50,color: Colors.white.withOpacity(0.6),
                      decoration: TextDecoration.none,),

                ),
                TextSpan(
                  text: " Tracker\n",

                  style: TextStyle(fontStyle:FontStyle.italic,fontSize:50,color: Colors.white.withOpacity(0.8),
                      decoration: TextDecoration.none),
                ),




              ],

            ),

          ),


            SizedBox(height:400,),

            ResponsiveButton(width:300,),

    ],
          )
],

        )
    ),


      );

  }


}













