import 'dart:ui';
class AppColors{
  static final Color textColor1=Color(0xFF989acd);
  static final Color textColor2=Color(0xff55565f);
  static final Color bigTextColor=Color(0xffc2a911);
  static final Color mainColor=Color(0xffb72134);
  static final Color starColor=Color(0xff54ab0c);
  static final Color mainTextColor=Color(0xff0a0909);
  static final Color buttonBackground=Color(0xff08c7b8);

}